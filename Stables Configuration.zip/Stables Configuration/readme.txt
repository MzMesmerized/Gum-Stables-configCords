Simply replace your configCords with this one.

It corrects the name for Annesburg Stable, adds Pronghorn, Caliga Hall, Macfarlanes, Armadillo and Colter stables. It also adds breeder stores to each stable.


Remember to rename all the jobs to the breeder stores with the appropriate jobs you have created.

Enjoy!

~ Mezzy